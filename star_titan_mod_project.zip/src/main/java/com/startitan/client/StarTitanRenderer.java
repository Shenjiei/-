package com.startitan.client;

import com.startitan.StarTitanEntity;
import com.startitan.StarTitanMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

public class StarTitanRenderer extends GeoEntityRenderer<StarTitanEntity> {
    public StarTitanRenderer(EntityRendererProvider.Context context) {
        super(context, new DefaultedEntityGeoModel<>(StarTitanMod.id("star_titan")));
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        this.shadowRadius = 2.0F;
    }
}
