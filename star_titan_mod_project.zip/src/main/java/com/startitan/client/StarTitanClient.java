package com.startitan.client;

import com.startitan.StarTitanMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class StarTitanClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(StarTitanMod.STAR_TITAN, StarTitanRenderer::new);
    }
}
