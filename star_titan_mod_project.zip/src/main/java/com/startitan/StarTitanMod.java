package com.startitan;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

public class StarTitanMod implements ModInitializer {
    public static final String MOD_ID = "star_titan";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    public static final EntityType<StarTitanEntity> STAR_TITAN = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            id("star_titan"),
            EntityType.Builder.<StarTitanEntity>of(StarTitanEntity::new, MobCategory.MONSTER)
                    .sized(3.5F, 6.5F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .build("star_titan"));

    public static final Item STAR_TITAN_SPAWN_EGG = Registry.register(
            BuiltInRegistries.ITEM,
            id("star_titan_spawn_egg"),
            new SpawnEggItem(STAR_TITAN, 0x0B2D5E, 0x9FE8FF, new Item.Properties()));

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(STAR_TITAN, StarTitanEntity.createAttributes());
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS)
                .register(entries -> entries.accept(STAR_TITAN_SPAWN_EGG));
    }
}
