package com.startitan;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * 星穹泰坦 Boss
 * - 800 血，蓝色 Boss 血条
 * - 近战挥爪 + 咬合
 * - 咆哮：减速、虚弱、击退附近玩家
 * - 星陨：在目标周围召唤坠落的星光，落点造成伤害（不破坏方块）
 * - 目标在高处或距离太远时会起飞追击
 * - 血量低于一半进入二阶段：更快、星陨更多更频繁
 */
public class StarTitanEntity extends Monster implements GeoEntity {

    private static final EntityDataAccessor<Boolean> FLYING =
            SynchedEntityData.defineId(StarTitanEntity.class, EntityDataSerializers.BOOLEAN);

    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.star_titan.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.star_titan.walk");
    private static final RawAnimation FLY = RawAnimation.begin().thenLoop("animation.star_titan.fly");
    private static final RawAnimation ROAR = RawAnimation.begin().thenPlay("animation.star_titan.roar");
    private static final RawAnimation ATTACK = RawAnimation.begin().thenPlay("animation.star_titan.attack");

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            this.getDisplayName(), BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.PROGRESS);

    private int roarCooldown = 100;
    private int roarPending = 0;
    private int starfallCooldown = 160;
    private int flyCooldown = 60;
    private int flyTicks = 0;
    private int actionTicks = 0;
    private boolean phaseTwo = false;
    private final List<Strike> strikes = new ArrayList<>();

    private static final class Strike {
        final double x;
        final double y;
        final double z;
        int ticks;

        Strike(double x, double y, double z, int ticks) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.ticks = ticks;
        }
    }

    public StarTitanEntity(EntityType<? extends StarTitanEntity> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setPersistenceRequired();
        this.bossEvent.setDarkenScreen(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 800.0D)
                .add(Attributes.ATTACK_DAMAGE, 18.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 2.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 12.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 6.0D)
                .add(Attributes.STEP_HEIGHT, 2.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(FLYING, false);
    }

    public boolean isTitanFlying() {
        return this.entityData.get(FLYING);
    }

    private void setTitanFlying(boolean flying) {
        this.entityData.set(FLYING, flying);
        this.setNoGravity(flying);
    }

    // ---------------- Boss 血条 ----------------

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        this.bossEvent.setName(this.getDisplayName());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (this.hasCustomName()) {
            this.bossEvent.setName(this.getDisplayName());
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return false;
    }

    // ---------------- 战斗 ----------------

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit) {
            this.triggerAnim("action", "attack");
            this.playSound(SoundEvents.RAVAGER_ATTACK, 2.0F, 0.6F);
        }
        return hit;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());

        if (this.roarCooldown > 0) this.roarCooldown--;
        if (this.starfallCooldown > 0) this.starfallCooldown--;
        if (this.flyCooldown > 0) this.flyCooldown--;
        if (this.actionTicks > 0) this.actionTicks--;

        if (!this.phaseTwo && this.getHealth() < this.getMaxHealth() * 0.5F) {
            this.phaseTwo = true;
            AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) speed.setBaseValue(0.34D);
            this.roarCooldown = 0;
        }

        this.tickStrikes();

        if (this.roarPending > 0) {
            this.roarPending--;
            if (this.roarPending == 0) this.roarBlast();
        }

        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            if (this.isTitanFlying()) this.setTitanFlying(false);
            return;
        }
        double dist = this.distanceTo(target);

        this.tickFlight(target, dist);

        if (this.roarCooldown == 0 && this.actionTicks == 0 && dist < 14.0D) {
            this.roarCooldown = this.phaseTwo ? 200 : 320;
            this.actionTicks = 60;
            this.roarPending = 20;
            this.triggerAnim("action", "roar");
            this.playSound(SoundEvents.ENDER_DRAGON_GROWL, 5.0F, 0.6F);
        } else if (this.starfallCooldown == 0 && this.actionTicks == 0 && dist < 32.0D) {
            this.starfallCooldown = this.phaseTwo ? 140 : 240;
            this.actionTicks = 30;
            this.triggerAnim("action", "attack");
            this.summonStarfall(target);
        }
    }

    private void tickFlight(LivingEntity target, double dist) {
        boolean targetHigh = target.getY() - this.getY() > 5.0D;
        if (!this.isTitanFlying()) {
            if ((targetHigh || dist > 22.0D) && this.flyCooldown == 0) {
                this.setTitanFlying(true);
                this.flyTicks = 120;
            }
            return;
        }
        this.flyTicks--;
        Vec3 goal = target.position().add(0.0D, 2.0D, 0.0D);
        Vec3 diff = goal.subtract(this.position());
        double len = diff.length();
        Vec3 dir = len > 0.001D ? diff.scale(1.0D / len) : Vec3.ZERO;
        double speed = len > 6.0D ? 0.6D : 0.2D;
        this.setDeltaMovement(this.getDeltaMovement().scale(0.8D).add(dir.scale(speed * 0.2D)));
        this.getLookControl().setLookAt(target, 30.0F, 30.0F);
        this.setYRot((float) (Mth.atan2(diff.z, diff.x) * (180.0D / Math.PI)) - 90.0F);
        this.yBodyRot = this.getYRot();
        if (this.flyTicks <= 0 || (len < 5.0D && !targetHigh)) {
            this.setTitanFlying(false);
            this.flyCooldown = 200;
        }
    }

    private void roarBlast() {
        if (!(this.level() instanceof ServerLevel server)) return;
        AABB area = this.getBoundingBox().inflate(14.0D);
        for (Player player : server.getEntitiesOfClass(Player.class, area)) {
            if (player.isCreative() || player.isSpectator() || this.distanceTo(player) > 14.0F) continue;
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2));
            player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            player.hurt(this.damageSources().mobAttack(this), 6.0F);
            player.knockback(1.6D, this.getX() - player.getX(), this.getZ() - player.getZ());
            player.hurtMarked = true;
        }
        server.sendParticles(ParticleTypes.SONIC_BOOM, this.getX(), this.getY() + 4.5D, this.getZ(), 1, 0, 0, 0, 0);
        for (int i = 0; i < 48; i++) {
            double a = i * Math.PI * 2.0D / 48.0D;
            server.sendParticles(ParticleTypes.END_ROD,
                    this.getX() + Math.cos(a) * 3.0D, this.getY() + 1.0D, this.getZ() + Math.sin(a) * 3.0D,
                    1, Math.cos(a) * 0.6D, 0.05D, Math.sin(a) * 0.6D, 0.3D);
        }
    }

    private void summonStarfall(LivingEntity target) {
        int count = this.phaseTwo ? 5 : 3;
        for (int i = 0; i < count; i++) {
            double ox = i == 0 ? 0.0D : (this.random.nextDouble() - 0.5D) * 8.0D;
            double oz = i == 0 ? 0.0D : (this.random.nextDouble() - 0.5D) * 8.0D;
            this.strikes.add(new Strike(target.getX() + ox, target.getY(), target.getZ() + oz, 25 + i * 4));
        }
        this.playSound(SoundEvents.BEACON_ACTIVATE, 4.0F, 0.5F);
    }

    private void tickStrikes() {
        if (this.strikes.isEmpty() || !(this.level() instanceof ServerLevel server)) return;
        Iterator<Strike> it = this.strikes.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            s.ticks--;
            // 预警光圈 + 下落的星光
            for (int i = 0; i < 8; i++) {
                double a = (i / 8.0D) * Math.PI * 2.0D + s.ticks * 0.3D;
                server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        s.x + Math.cos(a) * 2.5D, s.y + 0.1D, s.z + Math.sin(a) * 2.5D, 1, 0, 0, 0, 0);
            }
            double fall = s.y + Math.max(0, s.ticks) * 0.6D;
            server.sendParticles(ParticleTypes.END_ROD, s.x, fall, s.z, 6, 0.3D, 0.3D, 0.3D, 0.02D);
            if (s.ticks <= 0) {
                server.sendParticles(ParticleTypes.EXPLOSION, s.x, s.y + 0.5D, s.z, 3, 0.8D, 0.3D, 0.8D, 0);
                server.sendParticles(ParticleTypes.FIREWORK, s.x, s.y + 0.5D, s.z, 40, 0.5D, 0.5D, 0.5D, 0.35D);
                server.playSound(null, s.x, s.y, s.z, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST,
                        SoundSource.HOSTILE, 3.0F, 0.6F);
                AABB box = new AABB(s.x - 2.5D, s.y - 1.0D, s.z - 2.5D, s.x + 2.5D, s.y + 3.0D, s.z + 2.5D);
                for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, box)) {
                    if (e == this) continue;
                    e.hurt(this.damageSources().indirectMagic(this, this), this.phaseTwo ? 16.0F : 12.0F);
                }
                it.remove();
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide && this.random.nextFloat() < 0.35F) {
            this.level().addParticle(ParticleTypes.END_ROD,
                    this.getRandomX(1.2D), this.getY() + this.random.nextDouble() * 6.0D, this.getRandomZ(1.2D),
                    0.0D, 0.02D, 0.0D);
        }
    }

    // ---------------- GeckoLib 动画 ----------------

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "move", 6, this::moveController));
        controllers.add(new AnimationController<>(this, "action", 3, state -> PlayState.STOP)
                .triggerableAnim("roar", ROAR)
                .triggerableAnim("attack", ATTACK));
    }

    private PlayState moveController(AnimationState<StarTitanEntity> state) {
        if (this.isTitanFlying()) return state.setAndContinue(FLY);
        if (state.isMoving()) return state.setAndContinue(WALK);
        return state.setAndContinue(IDLE);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
